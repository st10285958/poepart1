package userapp;

public class MyClass {
    public static void main(String[] args) {
        try {
            UserRegistration registration = new UserRegistration();
            registration.registerUser(); // Handle new user registration
            registration.loginUser();    // Then allow the user to login
            registration.showAllUsers(); // Show all registered users
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }
}
