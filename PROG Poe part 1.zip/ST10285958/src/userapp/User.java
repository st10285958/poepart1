package userapp;

public class User {
    String username;
    String password;
    String phoneNumber;

    // Constructor to store user details
    public User(String username, String password, String phoneNumber) {
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }
}
