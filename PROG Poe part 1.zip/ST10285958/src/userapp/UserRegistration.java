package userapp;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class UserRegistration {
    Scanner scan = new Scanner(System.in);
    ArrayList<User> userList = new ArrayList<>(); // Stores all users

    public void registerUser() {
        try {
            String username = captureUsername();   // Ask for username
            String password = capturePassword();   // Ask for password
            String phoneNumber = captureCellNumber(); // Ask for phone number

            if (username != null && password != null && phoneNumber != null) {
                userList.add(new User(username, password, phoneNumber)); // Add to list if all valid
                System.out.println("User registered successfully.\n");
            } else {
                System.out.println("Registration failed due to invalid inputs.");
            }
        } catch (Exception e) {
            System.out.println("Error during registration: " + e.getMessage());
        }
    }

    public String captureUsername() {
        while (true) {
            System.out.println("Welcome to our chatbot. Please create a username:");
            String username = scan.nextLine().trim();

            if (username.isEmpty()) {
                System.out.println("Username cannot be empty.");
                continue;
            }

            if (username.length() <= 5 && username.contains("_")) {
                System.out.println("Username was captured successfully.");
                return username;
            } else {
                System.out.println("Username is not correctly formatted. Please ensure it contains an underscore and is no more than 5 characters.");
            }
        }
    }

    public String capturePassword() {
        while (true) {
            System.out.println("Please create a password (at least 8 characters, 1 capital letter, 1 number, 1 special character):");
            String password = scan.nextLine().trim();

            if (password.isEmpty()) {
                System.out.println("Password cannot be empty.");
                continue;
            }

            if (isValidPassword(password)) {
                System.out.println("Password stored successfully.");
                return password;
            } else {
                System.out.println("Password doesn't meet requirements. Try again:");
            }
        }
    }

    private boolean isValidPassword(String password) {
        String pattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        return Pattern.matches(pattern, password);
    }

    public String captureCellNumber() {
        while (true) {
            System.out.print("Enter cell phone number (with country code, e.g. +27123456789): ");
            String phoneNumber = scan.nextLine().trim();

            if (phoneNumber.isEmpty()) {
                System.out.println("Phone number cannot be empty.");
                continue;
            }

            String regex = "^\\+\\d{10,13}$";
            if (Pattern.matches(regex, phoneNumber)) {
                System.out.println("Cell phone number successfully added.");
                return phoneNumber;
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            }
        }
    }

    public void showAllUsers() {
        System.out.println("\nRegistered Users:");
        if (userList.isEmpty()) {
            System.out.println("No users found.");
        } else {
            for (User user : userList) {
                System.out.println("Username: " + user.username + " | Password: " + user.password + " | Phone: " + user.phoneNumber);
            }
        }
    }

    public void loginUser() {
        try {
            System.out.println("\n--- User Login ---");
            System.out.print("Enter your username: ");
            String usernameInput = scan.nextLine().trim();
            System.out.print("Enter your password: ");
            String passwordInput = scan.nextLine().trim();

            if (usernameInput.isEmpty() || passwordInput.isEmpty()) {
                System.out.println("Login fields cannot be empty.");
                return;
            }

            boolean isLoggedIn = false;
            for (User user : userList) {
                if (user.username.equals(usernameInput) && user.password.equals(passwordInput)) {
                    isLoggedIn = true;
                    break;
                }
            }

            if (isLoggedIn) {
                System.out.println("Login successful. Welcome back!");
            } else {
                System.out.println("Invalid username or password.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input format. Please try again.");
        } catch (Exception e) {
            System.out.println("An error occurred during login: " + e.getMessage());
        }
    }
}
